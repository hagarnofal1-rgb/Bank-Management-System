package bank2;

public abstract class BankAccount implements Transferable {

    protected String accountNumber;
    protected String ownerName;
    protected double balance;

    // Constructor
    public BankAccount(String accountNumber, String ownerName, double balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    // Deposit method
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    // Abstract methods
    public abstract void withdraw(double amount);
    public abstract String getAccountType();

    // Getter
    public double getBalance() {
        return balance;
    }

    // Transfer method from Transferable interface
    @Override
    public void transfer(BankAccount toAccount, double amount) {
        if (amount <= balance) {
            this.withdraw(amount);
            toAccount.deposit(amount);
        } else {
            System.out.println("Transfer failed: insufficient balance");
        }
    }
}
