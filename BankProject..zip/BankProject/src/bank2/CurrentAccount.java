package bank2;

public class CurrentAccount extends BankAccount {

        public CurrentAccount(String accountNumber, String ownerName, double balance) {
            super(accountNumber, ownerName, balance);
        }

        @Override
        public void withdraw(double amount) {

            balance -= amount; // يسمح بالسحب على المكشوف
        }

        @Override
        public String getAccountType() {

            return "Current Account";
        }
    }
