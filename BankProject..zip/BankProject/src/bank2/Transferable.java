package bank2;

    public interface Transferable {
        void transfer(BankAccount toAccount, double amount);

        void withdraw(double amount);
    }
