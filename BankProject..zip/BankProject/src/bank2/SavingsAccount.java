package bank2;

    public class SavingsAccount extends BankAccount {

        public SavingsAccount(String accountNumber, String ownerName, double balance) {
            super(accountNumber, ownerName, balance);
        }

        @Override
        public void withdraw(double amount) {
            if (amount <= balance) {
                balance -= amount;
            } else {
                System.out.println("Insufficient balance in Savings Account");
            }
        }

        @Override
        public String getAccountType() {
            return "Savings Account";
        }
    }
