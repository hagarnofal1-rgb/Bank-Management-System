package bank2;

public class Main {
    public static void main(String[] args) {

        BankAccount acc1 = new SavingsAccount("101", "Hagar", 1000);
        BankAccount acc2 = new CurrentAccount("202", "Ali", 500);

        System.out.println("===Initial Balances ===");
        System.out.println(acc1.getAccountType() + " Balance: " + acc1.getBalance());
        System.out.println(acc2.getAccountType() + " Balance: " + acc2.getBalance());
        System.out.println();
// deposit
        System.out.println("=== Deposit 200 to SavingsAccount ===");
        acc1.deposit(200);
        System.out.println(acc1.getAccountType() + " Balance: " + acc1.getBalance());
        System.out.println();
//withdraw
        System.out.println("=== Withdraw 300 from SavingsAccount ===");
        acc1.withdraw(300);
        System.out.println(acc1.getAccountType() + " Balance: " + acc1.getBalance());
        System.out.println();

        System.out.println("=== Withdraw 600 from CurrentAccount ===");
        acc2.withdraw(600);
        System.out.println(acc2.getAccountType() + " Balance: " + acc2.getBalance());
        System.out.println();

//transfer
        System.out.println("=== Transfer 400 from SavingsAccount to CurrentAccount ===");
        acc1.transfer(acc2, 400);
        System.out.println(acc1.getAccountType() + " Balance: " + acc1.getBalance());
        System.out.println(acc2.getAccountType() + " Balance: " + acc2.getBalance());
    }
}
